-- Savass Development

fx_version "cerulean"
game "gta5"
lua54 'yes'


author "Savass"
description "Savass Development Anti dump"
version "1.0.0"

server_scripts {
    "@oxmysql/lib/MySQL.lua",
    "server/*.lua"
}

server_only 'yes'

-- Savass Developmet

dependency '/assetpacks'